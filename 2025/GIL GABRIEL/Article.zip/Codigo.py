# -*- coding: utf-8 -*-
"""
Integração de Filtros Digitais na Análise de Sinais de Corrente
para Detecção de Arco Elétrico Segundo NBR IEC 62606
Gil Gabriel Muanido
Universidade Federal de Santa Maria (UFSM)
Programa de Pós-Graduação em Engenharia Elétrica – PPGEE
Santa Maria - RS, Brasil
Email: gil.muanido@acad.ufsm.br
ORCID: 0009-0005-7019-6445
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import firwin, convolve
import pywt

# ============================
# CONSTANTES DO SISTEMA
# ============================
V_MAX = 311.0       # Tensão de pico (V)
FREQ = 60.0         # Frequência (Hz)
R = 10.0            # Resistência (Ω)
TAU_C = 100e-6      # Constante de tempo Cassie (s)
TAU_M = 80e-6       # Constante de tempo Mayr (s)
UC = 50.0           # Tensão característica (V)
P0 = 80.0           # Potência característica (W)

# Parâmetros de simulação
T_FINAL = 0.05      # Tempo de simulação (s)
FS = 50000          # Frequência de amostragem (Hz)
T_STEP = 1 / FS     # Passo de tempo (s)
T = np.linspace(0, T_FINAL, int(FS * T_FINAL))  # Vetor de tempo

# Configurações de análise
FIR_FC = 2000       # Frequência de corte do filtro FIR (Hz)
FIR_ORDER = 101     # Ordem do filtro FIR
WAVELET_LEVEL = 5   # Nível de decomposição Wavelet
WAVELET_TYPE = 'db4'  # Tipo de Wavelet
NOISE_SEED = 98     # Semente para geração de números aleatórios

# ============================
# FUNÇÃO DE FONTE SENOIDAL
# ============================
def v_source(t):
    """Gera um sinal senoidal de tensão."""
    return V_MAX * np.sin(2 * np.pi * FREQ * t)

# ============================
# GERAÇÃO DE SINAIS
# ============================
def corrente_normal(amplitude):
    """Gera uma corrente senoidal pura."""
    return amplitude * np.sin(2 * np.pi * FREQ * T)

def falha_em_serie(normal, intensidade=0.1, janela_seg=0.0005):
    """Simula falha em série com redução de amplitude em cruzamentos por zero."""
    modificado = np.copy(normal)
    zcs = np.where(np.diff(np.sign(normal)))[0]  # Encontra cruzamentos por zero
    
    # Calcula intervalos ao redor dos cruzamentos
    samples_window = int(janela_seg / T_STEP)
    indices = np.concatenate([np.arange(max(0, zc - samples_window), 
                                       min(len(T), zc + samples_window + 1)) for zc in zcs])
    modificado[indices] *= intensidade
    modificado += np.random.default_rng(NOISE_SEED).normal(0, 0.05, len(T))
    return modificado

def falha_em_paralelo(normal, inicio=0.015, duracao=0.01):
    """Simula falha em paralelo com adição de ruído em intervalo específico."""
    sinal = np.copy(normal)
    idx_ini = int(inicio / T_STEP)
    idx_fim = int((inicio + duracao) / T_STEP)
    rng = np.random.default_rng(NOISE_SEED)
    ruido = rng.normal(0, 0.5 * np.max(np.abs(normal)), idx_fim - idx_ini)
    sinal[idx_ini:idx_fim] += ruido
    return sinal

def sinal_com_imunidade(normal, nivel_ruido=0.01):
    """Adiciona ruído gaussiano baixo para simular imunidade."""
    rng = np.random.default_rng(NOISE_SEED)
    return normal + rng.normal(0, nivel_ruido, len(normal))

# ============================
# ANÁLISE DE SINAIS
# ============================
def aplicar_filtros(sinal):
    """Aplica filtragem FIR e Transformada Wavelet."""
    # Filtro FIR passa-alta
    fir_coeffs = firwin(FIR_ORDER, FIR_FC / (FS / 2), window='hamming', pass_zero=False)
    sinal_fir = convolve(sinal, fir_coeffs, mode='same')
    
    # Transformada Wavelet
    coeffs = pywt.wavedec(sinal, WAVELET_TYPE, level=WAVELET_LEVEL)
    detail_coeffs = coeffs[WAVELET_LEVEL]
    t_dwt = np.linspace(0, T_FINAL, len(detail_coeffs))
    
    return sinal_fir, detail_coeffs, t_dwt

def plotar_analise(t, original, fir, t_dwt, wavelet, titulo):
    """Plota os três domínios de análise."""
    plt.figure(figsize=(12, 9))
    
    plt.subplot(3, 1, 1)
    plt.plot(t * 1000, original, color='blue')
    plt.ylabel('Corrente (A)')
    plt.title(f'{titulo} - Sinal Original')
    plt.grid(True)

    plt.subplot(3, 1, 2)
    plt.plot(t * 1000, fir, color='green')
    plt.ylabel('Corrente (A)')
    plt.title('Filtragem FIR - Passa-alta 2 kHz')
    plt.grid(True)

    plt.subplot(3, 1, 3)
    plt.plot(t_dwt * 1000, wavelet, color='purple')
    plt.xlabel('Tempo (ms)')
    plt.ylabel('Amplitude')
    plt.title(f'Transformada Wavelet - Coeficientes Detalhe ({WAVELET_TYPE})')
    plt.grid(True)

    plt.tight_layout()
    plt.show()

# ============================
# EXECUÇÃO PRINCIPAL
# ============================
def main():
    AMPLITUDE = 10
    sinal_base = corrente_normal(AMPLITUDE)
    
    # Falha em série
    sinal_serie = falha_em_serie(sinal_base)
    sinal_fir, coeffs_dwt, t_dwt = aplicar_filtros(sinal_serie)
    plotar_analise(T, sinal_serie, sinal_fir, t_dwt, coeffs_dwt, 'Falha de Arco em Série')
    
    # Falha em paralelo
    sinal_paralelo = falha_em_paralelo(sinal_base)
    sinal_fir, coeffs_dwt, t_dwt = aplicar_filtros(sinal_paralelo)
    plotar_analise(T, sinal_paralelo, sinal_fir, t_dwt, coeffs_dwt, 'Falha de Arco em Paralelo')
    
    # Sinal imune
    sinal_imune = sinal_com_imunidade(sinal_base)
    sinal_fir, coeffs_dwt, t_dwt = aplicar_filtros(sinal_imune)
    plotar_analise(T, sinal_imune, sinal_fir, t_dwt, coeffs_dwt, 'Sinal com Imunidade')

if __name__ == "__main__":
    main()
